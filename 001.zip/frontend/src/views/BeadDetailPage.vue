<template>
  <section v-if="project" class="card">
    <div class="row-between" style="margin-bottom:12px;">
      <h2 class="section-title">拼豆详情：{{ form.name || project.name }}</h2>
      <RouterLink class="btn secondary" to="/overview">返回总览</RouterLink>
    </div>

    <div class="tabs">
      <button class="tab" :class="{active: tab==='overview'}" @click="tab='overview'">概况</button>
      <button class="tab" :class="{active: tab==='work'}" @click="tab='work'">开始拼豆</button>
    </div>

    <div v-if="tab==='overview'" style="display:grid; gap:12px;">
      <label>拼豆名称
        <input class="input" v-model="form.name" />
      </label>

      <label>拼豆 tag（可复用）</label>
      <div class="card" style="padding:10px;">
        <div class="row" style="flex-wrap:wrap; margin-bottom:8px;">
          <label v-for="tag in existingTags" :key="tag" style="display:flex;align-items:center;gap:4px;">
            <input type="checkbox" :value="tag" v-model="selectedTags" /> {{ tag }}
          </label>
        </div>
        <div class="row">
          <input class="input" v-model="newTag" placeholder="新增 tag" />
          <button class="btn secondary" @click="addCustomTag">添加</button>
        </div>
      </div>

      <label>图纸来源链接
        <input class="input" v-model="form.sourceUrl" placeholder="https://..." />
      </label>

      <div style="display:grid; gap:8px;">
        <label>拼豆图纸
          <input class="input" type="file" accept="image/*" @change="onPattern" />
        </label>
        <div class="row">
          <button class="btn secondary" @click="clearPatternImage">清空拼豆图纸</button>
        </div>
        <img v-if="form.patternImage" :src="form.patternImage" style="display:block;max-width:380px;margin-top:6px;border-radius:8px;" />
        <span v-else>暂无</span>
      </div>

      <div style="display:grid; gap:8px;">
        <label>我的作品
          <input class="input" type="file" accept="image/*" @change="onWork" />
        </label>
        <div class="row">
          <button class="btn secondary" @click="clearWorkImage">清空我的作品</button>
        </div>
        <img v-if="form.workImage" :src="form.workImage" style="display:block;max-width:380px;margin-top:6px;border-radius:8px;" />
        <span v-else>暂无</span>
      </div>

      <div class="row">
        <button class="btn success" @click="saveProject" :disabled="saving">{{ saving ? '保存中...' : '保存详情' }}</button>
      </div>

    </div>

    <BeadWorkbench v-else :project="project" />
  </section>

  <section v-else class="card">加载中...</section>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { useRoute } from 'vue-router'
import { beadApi } from '@/api/beads'
import type { BeadProject } from '@/types'
import BeadWorkbench from '@/components/BeadWorkbench.vue'

const route = useRoute()
const tab = ref<'overview' | 'work'>('overview')
const project = ref<BeadProject | null>(null)
const saving = ref(false)
const existingTags = ref<string[]>([])
const selectedTags = ref<string[]>([])
const newTag = ref('')
const form = reactive({
  name: '',
  sourceUrl: '',
  patternImage: '',
  workImage: ''
})

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result || ''))
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

function applyProjectToForm(detail: BeadProject) {
  form.name = detail.name || ''
  form.sourceUrl = detail.sourceUrl || ''
  form.patternImage = detail.patternImage || ''
  form.workImage = detail.workImage || ''
  selectedTags.value = [...(detail.tags || [])]
}

async function loadProject() {
  const id = Number(route.params.id)
  const [detail, tags] = await Promise.all([beadApi.detail(id), beadApi.tags()])
  project.value = detail
  existingTags.value = tags
  applyProjectToForm(detail)
}

async function onPattern(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  form.patternImage = await fileToBase64(file)
}

async function onWork(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]
  if (!file) return
  form.workImage = await fileToBase64(file)
}

function clearPatternImage() {
  form.patternImage = ''
}

function clearWorkImage() {
  form.workImage = ''
}

function addCustomTag() {
  const tag = newTag.value.trim()
  if (!tag) return
  if (!existingTags.value.includes(tag)) {
    existingTags.value.push(tag)
  }
  if (!selectedTags.value.includes(tag)) {
    selectedTags.value.push(tag)
  }
  newTag.value = ''
}

async function saveProject() {
  if (!project.value) return
  if (!form.name.trim()) {
    alert('拼豆名称不能为空')
    return
  }
  saving.value = true
  try {
    const updated = await beadApi.update(project.value.id, {
      name: form.name,
      tags: selectedTags.value,
      sourceUrl: form.sourceUrl,
      patternImage: form.patternImage,
      workImage: form.workImage
    })
    project.value = updated
    applyProjectToForm(updated)
    alert('详情已保存')
  } catch (error) {
    console.error(error)
    alert('保存失败，请稍后重试')
  } finally {
    saving.value = false
  }
}

onMounted(async () => {
  try {
    await loadProject()
  } catch (error) {
    console.error(error)
    alert('加载详情失败，请稍后重试')
  }
})
</script>
