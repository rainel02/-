package com.pindou.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PindouApplication {
    public static void main(String[] args) {
        SpringApplication.run(PindouApplication.class, args);
    }
}
