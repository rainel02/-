package com.pindou.app.model;

public enum BeadStatus {
    DONE,
    IN_PROGRESS,
    TODO
}
