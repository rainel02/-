package com.pindou.app.repository;

import com.pindou.app.model.BeadProject;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BeadProjectRepository extends JpaRepository<BeadProject, Long> {
}
